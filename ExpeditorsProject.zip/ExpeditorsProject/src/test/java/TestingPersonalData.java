import Models.PersonalInformation;
import Utility.PersonalDataSorting;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import java.util.*;

public class TestingPersonalData {
    @Test
    public  void sortAndAssertTheAgeOlder18(){
        System.out.println("=================PERSONAL INFO================\n");
        List<Map<String,List<PersonalInformation>>> newData = PersonalDataSorting.sortByLastFirstAddr();
        List<PersonalInformation> peopleOlderThan18= new ArrayList<>();
        for(int i=0; newData.size()-1>=i; i++){
            Map<String,List<PersonalInformation>> eachMap = newData.get(i);
            for(List<PersonalInformation> eachListOfObjects: eachMap.values()){
                int countPeopleInHoushold = 0;
                for(int f=0; eachListOfObjects.size()-1>=f; f++){
                    PersonalInformation eachObj = eachListOfObjects.get(f);
                    if(eachObj.getAge()>18){
                        countPeopleInHoushold++;
                        peopleOlderThan18.add(eachObj);
                        System.out.println(eachObj.getFirtsName()+ " "+ eachObj.getLastName()+" "
                                + eachObj.getAge()+"; Address: "+eachObj.getStreetAddress()+" "+eachObj.getCityAddress());
                    }
                }
                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t\t"
                        +countPeopleInHoushold+" People in "+eachMap.keySet());
                System.out.println("=== === === ==== === ===");
            }
        }
        for(PersonalInformation eachPerson: peopleOlderThan18){
            Assertions.assertTrue(eachPerson.getAge()>18);
        }
    }

}
