package Models;

import com.opencsv.bean.CsvBindByPosition;

public class PersonalInformation {
    @CsvBindByPosition(position = 0)
    private String firtsName;

    @CsvBindByPosition(position = 1)
    private String lastName;

    @CsvBindByPosition(position = 2)
    private String streetAddress;

    @CsvBindByPosition(position = 3)
    private String cityAddress;

    @CsvBindByPosition(position = 4)
    private String stateAddress;

    @CsvBindByPosition(position = 5)
    private int age;

    public PersonalInformation(String firtsName, String lastName, String streetAddress, String cityAddress, String stateAddress, int age) {
        this.firtsName = firtsName;
        this.lastName = lastName;
        this.streetAddress = streetAddress;
        this.cityAddress = cityAddress;
        this.stateAddress = stateAddress;
        this.age = age;
    }
    public PersonalInformation(){}

    public void setFirtsName(String firtsName) {
        this.firtsName = firtsName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public void setCityAddress(String cityAddress) {
        this.cityAddress = cityAddress;
    }

    public void setStateAddress(String stateAddress) {
        this.stateAddress = stateAddress;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getFirtsName() {
        return firtsName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public String getCityAddress() {
        return cityAddress;
    }

    public String getStateAddress() {
        return stateAddress;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "{" +
                "firtsName='" + firtsName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", streetAddress='" + streetAddress + '\'' +
                ", cityAddress='" + cityAddress + '\'' +
                ", stateAddress='" + stateAddress + '\'' +
                ", age=" + age +
                '}';

    }

}
