package Utility;

import Models.PersonalInformation;
import com.opencsv.bean.CsvToBeanBuilder;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;

public class CsvFileReader {

    public static List<PersonalInformation> makeListOfData(){
      String fileName =  ConfigurationReader.getProperty("csvFileName");
        try {
            List<PersonalInformation> people = new CsvToBeanBuilder(new FileReader(fileName))
                    .withType(PersonalInformation.class)
                    .build()
                    .parse();
             return people;
        }catch (FileNotFoundException e){
            e.getMessage();
        }
        return null;
    }
}
