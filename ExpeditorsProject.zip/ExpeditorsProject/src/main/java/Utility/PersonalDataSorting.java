package Utility;

import Models.PersonalInformation;
import org.apache.commons.collections.list.TreeList;

import java.util.*;

public class PersonalDataSorting {

    public static List<Map<String,List<PersonalInformation>>> sortByLastFirstAddr() {
        List<PersonalInformation> listOfPeoleInHoushold = CsvFileReader.makeListOfData();
        List<Map<String, List<PersonalInformation>>> listOfMapsPersData = new TreeList();
        Set<String> removeDups = new TreeSet<>();

        //loop through and remove Duplicated lastName and add it into removeDups
        for (int i=1; listOfPeoleInHoushold.size()-1>=i; i++){
            String lastName = listOfPeoleInHoushold.get(i).getLastName();
            removeDups.add(lastName);
        }

        //add each lastName into listOfMaps
        for(String eachLastName: removeDups){
            Map<String,List<PersonalInformation>> map1 = new LinkedHashMap<>();
            map1.put(eachLastName,null);
            listOfMapsPersData.add(map1);
        }

        for(int j=0; listOfMapsPersData.size()-1>=j; j++){
            List<PersonalInformation> listOfObj = new LinkedList<>();
            for(int k=0; listOfPeoleInHoushold.size()-1>=k; k++){
                for(String lastName: listOfMapsPersData.get(j).keySet()){
                    if(lastName.equalsIgnoreCase(listOfPeoleInHoushold.get(k).getLastName())){
                        listOfObj.add(listOfPeoleInHoushold.get(k));
                        listOfMapsPersData.get(j).put(lastName,listOfObj);
                    }
                }
            }
            listOfObj.sort(Comparator.comparing(PersonalInformation::getFirtsName));
        }
        return listOfMapsPersData;
    }
}
